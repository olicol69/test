<?php

	$zone = $_GET['zone'];
	$valeur = $_GET['valeur'];
	$unite = $_GET['unite'];

	$e='';

	/* connection base de données */
	/* Connexion à une base ODBC avec l'invocation de pilote */

	/*
	$dsn = 'mysql:dbname=domotique;host=127.0.0.1';
	$user = 'root';
	$password = '';
	*/
	
	
	define('BDD_hote', 'mysql13.000webhost.com');
    define('BDD_user', 'a8204936_user');
    define('BDD_pass', 'y88x8cn2');
    define('BDD_nmDB', 'a8204936_domotik');

    try 
    {
        $bdd = new PDO('mysql:host='.BDD_hote.';dbname='.BDD_nmDB, BDD_user, BDD_pass);
    	$bdd->setAttribute(PDO::ATTR_ERRMODE,PDO::ERRMODE_WARNING);
		
        $bdd->setAttribute(PDO::ATTR_DEFAULT_FETCH_MODE,PDO::FETCH_OBJ);
		

		} catch (Exception $e) 
	{
        die('Erreur : ' . $e->getMessage());
	}
	/*
	$dsn = 'mysql13.000webhost.com';
	$user = 'a8204936_user';
	$password = 'y88x8cn2';
	$database = 'a8204936_domotik';
	$connect = @mysql_connect($dsn, $user, $password)or die(mysql_error());
	$bdd = @mysql_select_db($database,$connect)or die(mysql_error());
	*/
		
	// On ajoute une entrée dans la table mesure
	$requete = "insert INTO mesure(zone,valeur,unite) VALUES('".$zone."',".$valeur.",'".$unite."')";
	echo $requete;
	try
	{
		$row=$bdd->exec($requete);
	} catch (Exception $e) 
	{
        die('Erreur : ' . $e->getMessage());
	}


?>