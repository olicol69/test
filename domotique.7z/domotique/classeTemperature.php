<?php
	classe temperature {
		private $date;
		private $mesure;

		function getDate(){
			return $this->date;
		}

		function getMesure(){
			return $this->mesure;
		}

		function setGet($newDate){
			$this->date = $newDate;
		}

		function setMesure($newMesure){
			$this->mesure = $newMesure;
		}
	}
?>
